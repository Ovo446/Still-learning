export default function AboutPage() {
  return (
    <main className="min-h-screen p-6 bg-white text-black">
      <h1 className="text-3xl font-bold mb-4">About This Project</h1>
      <p>This site helps students grow their English ability by reading, thinking, and reflecting daily. Built with Next.js + TailwindCSS.</p>
    </main>
  );
}