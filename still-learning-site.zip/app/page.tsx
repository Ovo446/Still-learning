export default function Home() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center p-10 bg-white text-black">
      <h1 className="text-4xl font-bold mb-6">Welcome to Vocab Web</h1>

      <div className="space-x-4">
        <a
          href="/daily"
          className="bg-green-200 text-black px-4 py-2 rounded hover:bg-green-300 transition"
        >
          Daily Read
        </a>
        <a
          href="/about"
          className="bg-green-200 text-black px-4 py-2 rounded hover:bg-green-300 transition"
        >
          About
        </a>
      </div>
    </main>
  );
}