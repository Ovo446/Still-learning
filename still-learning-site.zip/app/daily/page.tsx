const sampleWords = [
  { word: "benevolent", meaning: "well meaning and kindly" },
  { word: "catalyst", meaning: "a substance that speeds up a reaction" },
  { word: "emerge", meaning: "to come into view" },
];

export default function DailyPage() {
  return (
    <main className="min-h-screen p-6 bg-gray-100 text-black">
      <h1 className="text-3xl font-semibold mb-4">Today's Vocabulary</h1>
      <ul className="space-y-2">
        {sampleWords.map(({ word, meaning }) => (
          <li key={word} className="bg-white p-4 rounded shadow">
            <strong>{word}</strong>: {meaning}
          </li>
        ))}
      </ul>
    </main>
  );
}