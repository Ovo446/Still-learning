
export default function About() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>About This Site</h1>
      <p>This is a simple English learning web app.</p>
    </div>
  );
}
