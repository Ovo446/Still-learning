
export default function Daily() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>Daily Read</h1>
      <p>Check back every day for something new to learn.</p>
    </div>
  );
}
